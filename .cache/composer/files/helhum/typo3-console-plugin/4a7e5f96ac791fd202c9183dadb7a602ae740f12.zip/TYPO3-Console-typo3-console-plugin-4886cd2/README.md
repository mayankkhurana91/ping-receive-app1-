# TYPO3 Console Plugin

Installer plugin for [helhum/typo3-console](https://github.com/helhum/typo3_console),
to ease usage of this package without the need to specify scripts in your root composer.json
