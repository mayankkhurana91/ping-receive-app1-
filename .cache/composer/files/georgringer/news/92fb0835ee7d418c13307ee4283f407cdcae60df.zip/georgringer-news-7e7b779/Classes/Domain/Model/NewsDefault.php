<?php
namespace GeorgRinger\News\Domain\Model;

/**
 * This file is part of the "news" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 */

/**
 * News model for default news
 *
 */
class NewsDefault extends \GeorgRinger\News\Domain\Model\News
{
}
