.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt

.. _records:

Records
-------

EXT:news uses multiples records which are described here in detail.

.. toctree::
	:maxdepth: 5
	:titlesonly:

	News/Index
	Category/Index
	Tag/Index

