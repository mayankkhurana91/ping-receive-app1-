.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Templates
---------

.. only:: html

	This chapter is all about templating EXT:news


.. toctree::
	:maxdepth: 1
	:titlesonly:

	Start/Index
	TwitterBootstrap/Index
	TemplateSelector/Index
	AjaxBasedPagination/Index
	ViewHelpers/Index
	Snippets/Index