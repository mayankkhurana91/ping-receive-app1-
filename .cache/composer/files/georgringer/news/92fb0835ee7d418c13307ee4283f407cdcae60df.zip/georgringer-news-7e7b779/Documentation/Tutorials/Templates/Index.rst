.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Templates
---------

.. toctree::
	:maxdepth: 5
	:titlesonly:

	RenderInColumns/Index
	RenderContentElements/Index
	GroupNewsRecords/Index
