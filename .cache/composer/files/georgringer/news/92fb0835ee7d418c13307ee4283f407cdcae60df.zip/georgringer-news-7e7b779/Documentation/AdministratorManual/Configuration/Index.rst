.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Configuration
-------------

.. only:: html

	This chapter describes how to the extension can be configured

.. toctree::
	:maxdepth: 5
	:titlesonly:

	TypoScript/Index
	TsConfig/Index
	ExtensionManager/Index