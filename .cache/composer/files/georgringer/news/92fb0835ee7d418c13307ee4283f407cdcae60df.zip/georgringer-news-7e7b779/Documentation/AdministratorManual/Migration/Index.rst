.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Migration
---------

EXT:news provides a powerful import module which can be used to add news and category records from various sources.

.. toctree::
	:maxdepth: 5
	:titlesonly:

	MigrationFromTtNews/Index
