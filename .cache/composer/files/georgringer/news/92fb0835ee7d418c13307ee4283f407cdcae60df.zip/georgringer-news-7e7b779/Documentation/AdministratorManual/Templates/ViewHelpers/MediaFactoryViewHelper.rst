MediaFactoryViewHelper
---------------------------

ViewHelper to show videos

**Type:** Basic


General properties
^^^^^^^^^^^^^^^^^^^^^^^

.. t3-field-list-table::
 :header-rows: 1

 - :Name: Name:
   :Type: Type:
   :Description: Description:
   :Default value: Default value:

 - :Name:
         \* classes
   :Type:
         string
   :Description:
         list of classes which are used to render the media object
   :Default value:
         

 - :Name:
         \* element
   :Type:
         Tx\_News\_Domain\_Model\_Media
   :Description:
         Current media object
   :Default value:
         

 - :Name:
         \* height
   :Type:
         integer
   :Description:
         height
   :Default value:
         

 - :Name:
         \* width
   :Type:
         integer
   :Description:
         width
   :Default value:

