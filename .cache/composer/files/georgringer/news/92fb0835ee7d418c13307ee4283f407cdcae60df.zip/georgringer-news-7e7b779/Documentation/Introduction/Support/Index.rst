.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt

.. _support:

Need Support?
=============
There are various ways to get support for EXT:news!

Stackoverflow
-------------
Please use https://stackoverflow.com to get best support. Tags you should use are `typo3` and `tx-news`, so your question will be visible at http://stackoverflow.com/questions/tagged/tx_news.

Slack
-----
A dedicated channel on slack can be be used to get in touch with other users!

The url is: https://typo3.slack.com/messages/ext-news/

.. note::

   If you are not yet registered, use http://forger.typo3.org/slack for that!

Sponsoring
----------
If you need a feature which is not yet implemented, feel free to contact me anytime!

Private/Personal support
------------------------
If you need private or personal support, ask one of the developers for it.

**Be aware that this support might not be free!**
