﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _developer-manual:

For developers
==============

.. only:: html

	This chapter describes how to use the extension from a developer point of view.

.. toctree::
	:maxdepth: 5
	:titlesonly:

	ExtendNews/Index
	Contribute/Index