﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.


Documentation best practice
===========================

.. only:: html

	Best practice for Documentation with rest

.. toctree::
	:maxdepth: 5
	:titlesonly:

	Examples/Index
	CrossLink/Index