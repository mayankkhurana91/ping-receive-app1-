Format / NothingViewHelper
-------------------------------

ViewHelper to render children which don't print out any actual content

**Type:** Basic


Examples
^^^^^^^^^^^^^

Basic example
""""""""""""""""""



Code: ::

	 <n:format.nothing>
	<n:titleTag>{newsItem.title}</n:titleTag>
	Fobar
	 </n:format.nothing>


Output: ::

	 nothing

