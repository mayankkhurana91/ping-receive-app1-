PaginateBodytextViewHelper
-------------------------------

Paginate the bodytext which is very useful for longer texts or to increase

**Type:** Basic


General properties
^^^^^^^^^^^^^^^^^^^^^^^

.. t3-field-list-table::
 :header-rows: 1

 - :Name: Name:
   :Type: Type:
   :Description: Description:
   :Default value: Default value:

 - :Name:
         \* as
   :Type:
         string
   :Description:
         name of property which holds the text
   :Default value:
         

 - :Name:
         \* currentPage
   :Type:
         integer
   :Description:
         Selected page
   :Default value:
         

 - :Name:
         \* object
   :Type:
         Tx\_News\_Domain\_Model\_News
   :Description:
         current news object
   :Default value:
         

 - :Name:
         token
   :Type:
         string
   :Description:
         Token used to split the text
   :Default value:
         ###more###

