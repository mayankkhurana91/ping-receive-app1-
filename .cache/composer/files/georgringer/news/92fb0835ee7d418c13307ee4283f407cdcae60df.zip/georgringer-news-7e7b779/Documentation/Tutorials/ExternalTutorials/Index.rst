.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


External tutorials
-------------------

There are already some additional 3rd party tutorials about the extension "news".

Video tutorials by jweiland
^^^^^^^^^^^^^^^^^^^^^^^^^^^

5 german video tutorials by Jochen Weiland which can be found at http://jweiland.net/typo3-hosting/service/video-anleitungen/typo3-extensions/news.html.

- Installation & Configuration: http://vimeo.com/63231058
- Create an article: http://vimeo.com/63231385
- Output in frontend: http://vimeo.com/63231754
- News archive: http://vimeo.com/63232250
- Multilanguage: http://vimeo.com/63232527


Add links to your own tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

If you have written an own tutorial or found one which is worth to be mentioned,
please open an issue in the bugtracker.