Social / Facebook / ShareViewHelper
----------------------------------------

ViewHelper to share content

**Type:** Tag Based


General properties
^^^^^^^^^^^^^^^^^^^^^^^

.. t3-field-list-table::
 :header-rows: 1

 - :Name: Name:
   :Type: Type:
   :Description: Description:
   :Default value: Default value:

 - :Name:
         loadJs
   :Type:
         boolean
   :Description:

   :Default value:
         1

 - :Name:
         type
   :Type:
         string
   :Description:
         default\: button\_count
   :Default value:

