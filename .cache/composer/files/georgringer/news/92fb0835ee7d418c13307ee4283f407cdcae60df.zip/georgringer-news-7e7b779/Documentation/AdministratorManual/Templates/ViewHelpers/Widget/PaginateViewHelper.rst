Widget / PaginateViewHelper
--------------------------------

This ViewHelper renders a Pagination of objects.

**Type:** Widget


General properties
^^^^^^^^^^^^^^^^^^^^^^^

.. t3-field-list-table::
 :header-rows: 1

 - :Name: Name
   :Type: Type
   :Description: Description
   :Default value: Default value

 - :Name:
         \* as
   :Type:
         string
   :Description:

   :Default value:


 - :Name:
         configuration
   :Type:
         mixed
   :Description:

   :Default value:
         Array

 - :Name:
         \* objects
   :Type:
         TYPO3\\CMS\\Extbase\\Persistence\\QueryResultInterface
   :Description:

   :Default value:

