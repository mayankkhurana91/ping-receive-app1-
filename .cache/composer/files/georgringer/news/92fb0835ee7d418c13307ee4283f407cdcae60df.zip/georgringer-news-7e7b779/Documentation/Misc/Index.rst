﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _misc:

Miscellaneous
=============

.. only:: html

	Misc

.. toctree::
	:maxdepth: 5
	:titlesonly:

	Changelog/Index
	MissingKnownErrors/Index
	DocumentationBestPractice/Index