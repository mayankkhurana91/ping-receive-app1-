TitleTagViewHelper
-----------------------

ViewHelper to render the page title

**Type:** Basic


Examples
^^^^^^^^^^^^^

Basic Example
""""""""""""""""""

Render the content of the VH as page title

Code: ::

	<n:titleTag>{newsItem.title}</n:titleTag>


Output: ::

	<title>TYPO3 is awesome</title>

