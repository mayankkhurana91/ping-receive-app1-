.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _labels-for-crossreferencing:

Labels for cross-referencing
----------------------------

.. ref-targets-list::