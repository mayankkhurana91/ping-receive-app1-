.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Best practice
-------------

.. only:: html

	This chapter describes some best practice concepts

.. toctree::
	:maxdepth: 5
	:titlesonly:

	PreviewOfRecord/Index
	IntegrationWithTypoScript/Index
	ClearCache/Index
	Realurl/Index
	PredefineFields/Index
	Rss/Index
	ICalendar/Index
	SitemapWithDdGoogleSitemap/Index
