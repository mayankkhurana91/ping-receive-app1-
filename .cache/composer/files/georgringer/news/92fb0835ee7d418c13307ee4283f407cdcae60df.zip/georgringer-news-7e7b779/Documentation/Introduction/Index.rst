﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. _introduction:

Introduction
============

.. only:: html

	This chapter gives you a basic introduction about the TYPO3 CMS extension "*news*".

.. toctree::
	:maxdepth: 5
	:titlesonly:

	About/Index
	Support/Index
	Thanks/Index
