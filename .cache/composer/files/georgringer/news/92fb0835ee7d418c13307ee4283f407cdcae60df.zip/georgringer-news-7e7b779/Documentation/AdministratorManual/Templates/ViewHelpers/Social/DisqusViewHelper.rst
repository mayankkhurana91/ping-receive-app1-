Social / DisqusViewHelper
------------------------------

ViewHelper to add disqus thread

**Type:** Basic


General properties
^^^^^^^^^^^^^^^^^^^^^^^

.. t3-field-list-table::
 :header-rows: 1

 - :Name: Name:
   :Type: Type:
   :Description: Description:
   :Default value: Default value:

 - :Name:
         \* link
   :Type:
         string
   :Description:
         link
   :Default value:
         

 - :Name:
         \* newsItem
   :Type:
         Tx\_News\_Domain\_Model\_News
   :Description:
         news item
   :Default value:
         

 - :Name:
         \* shortName
   :Type:
         string
   :Description:
         shortname
   :Default value:

