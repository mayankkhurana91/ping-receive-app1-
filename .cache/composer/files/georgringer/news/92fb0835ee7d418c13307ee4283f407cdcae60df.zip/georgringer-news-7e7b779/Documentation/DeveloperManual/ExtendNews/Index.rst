.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Extend News
-----------

.. toctree::
	:maxdepth: 5
	:titlesonly:

	ExtendFlexforms/Index
	HooksSignals/Index
	ProxyClassGenerator/Index
	ImportService/Index
	AddCustomType/Index
	ExtensionBasedOnNews/Index
