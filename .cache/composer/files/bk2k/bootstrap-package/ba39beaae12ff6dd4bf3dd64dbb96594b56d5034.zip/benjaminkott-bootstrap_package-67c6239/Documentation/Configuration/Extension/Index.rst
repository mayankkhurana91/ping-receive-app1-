﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


=======================
Extension Configuration
=======================

Use the extension manager to adjust the Bootstrap Package to your needs.


PageTsConfig
============

The Bootstrap Package has a lot of PageTsConfig defaults.
In some cases it can be useful to deactivate some of them if you do not need them.
