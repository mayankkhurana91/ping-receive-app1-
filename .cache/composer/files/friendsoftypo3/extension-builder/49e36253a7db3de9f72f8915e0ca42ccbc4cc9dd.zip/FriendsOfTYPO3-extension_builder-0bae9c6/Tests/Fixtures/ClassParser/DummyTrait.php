<?php

trait dummyTrait
{

    public function dummy()
    {
        // do nothing
    }
}
