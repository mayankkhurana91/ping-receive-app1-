<?php

return ['
a{f:base()}b'];
