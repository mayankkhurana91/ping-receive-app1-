<?php
namespace TYPO3Fluid\Fluid\Core\Parser;

/*
 * This file belongs to the package "TYPO3 Fluid".
 * See LICENSE.txt that was shipped with this package.
 */

/**
 * A Parsing Exception
 *
 * @api
 */
class Exception extends \TYPO3Fluid\Fluid\Core\Exception
{
}
