<?php
namespace TYPO3Fluid\Fluid;

/*
 * This file belongs to the package "TYPO3 Fluid".
 * See LICENSE.txt that was shipped with this package.
 */

/**
 * The most general Fluid exception.
 *
 * @api
 */
class Exception extends \RuntimeException
{
}
