﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt



.. _login-mechanism:

Login mechanism
---------------

In order to properly use the felogin plugin and its advanced
capabilities (such as redirect options) it is important to understand
the mechanism of frontend user login in TYPO3 CMS.


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Display/Index
   LoginProcess/Index
   RedirectModes/Index

