﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _display:

What is displayed?
^^^^^^^^^^^^^^^^^^

If there is no frontend user logged in, the login form will be
shown.

If there is a logged in frontend user, the logout form is shown.

If the forgot password link was used, the form to reset a password
based on username or email address will be shown.

If the password reset link was followed from an email, the form to
change the password will be shown.

