<?php
$EM_CONF[$_EXTKEY] = [
    'title' => 'Frontend Login for Website Users',
    'description' => 'A template-based plugin to log in Website Users in the Frontend',
    'category' => 'plugin',
    'author' => 'TYPO3 Core Team',
    'author_email' => 'typo3cms@typo3.org',
    'author_company' => '',
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'version' => '8.7.9',
    'constraints' => [
        'depends' => [
            'php' => '7.0.0-7.2.99',
            'typo3' => '8.7.9',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
